<?php 
include("functions.php");
//connect to db
//$dblink = db_connect("equipment");
//load device types in array
//$typeResult=$dblink->query("SELECT device_type_id, name FROM device_types WHERE status='active' ORDER BY name");
//$deviceTypes=[];
//while($r=$typeResult->fetch_assoc())
        //$deviceTypes[$r['device_type_id']]=$r['name'];
//load manufacs into array
//$mfrResult=$dblink->query("SELECT manufacturer_id, name FROM manufacturers WHERE status='active' ORDER BY name");
//$manufacturers=[];
//while($r=$mfrResult->fetch_assoc())
        //$manufacturers[$r['manufacturer_id']]=$r['name'];
//call api to get dev types for dropdowns
$deviceTypesResponse=callAPI('list_device_types');
$deviceTypes=$deviceTypesResponse['data'] ?? [];
//call api to get manus dropdowns
$manufacturersResponse=callAPI('list_manufacturer_types');
$manufacturers=$manufacturersResponse['data'] ?? [];
//get search mode from url
$mode=$_REQUEST['mode'] ?? '';
$error='';
//hold query results
$results=null;
//search device type
if($mode==='type') {
	//get dev_type and manuId from form
	$did=$_REQUEST['did'] ?? 0;
	$mid=$_REQUEST['mid'] ?? 0;
	//call to search type 
	$response=callAPI('search_equipment', array('mode'=>'type','did'=>$did,'mid'=>$mid));
	//check for successful response
	if($response['status']==='Success' && $response['data']!=='none') {
		//store in array
		$results=$response['data'];
	}
	else {
		$error=$response['message'];
	}
        //$typeId=(int)($_REQUEST['device_type_id'] ?? 0);
        //$mfrId=(int)($_REQUEST['manufacturer_id'] ?? 0);
        //query to join equipemnt, dev_type, manuID
        //only return active
        /*$sql="SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
                FROM equipment e
                JOIN device_types dt ON e.device_type_id = dt.device_type_id
                JOIN manufacturers m ON e.manufacturer_id = m.manufacturer_id
                WHERE dt.status='active' AND e.device_type_id = $typeId";
	 */
	//add specific manu to filter
        //0 means all manus
        //if($mfrId > 0) $sql .= " AND e.manufacturer_id = $mfrId";
        //$results = $dblink->query($sql);
}
//search by manu
elseif($mode==='manufacturer') {
	//get manu and dev type id from form
	$mid=$_REQUEST['mid'] ?? 0;
	$did=$_REQUEST['did'] ?? 0;
	//call searching with mode
	$response=callAPI('search_equipment', array('mode'=>'manufacturer','mid'=>$mid,'did'=>$did));
	//check for successful response
	if($response['status']==='Success' && $response['data']!=='none') {
		//store in array
		$results=$response['data'];
	}
	else {
		$error=$response['message'];
	}
        /*$mfrId=(int)($_REQUEST['manufacturer_id'] ?? 0);
        $typeId=(int)($_REQUEST['device_type_id'] ?? 0);
        //only return equipment when manu active
        $sql="SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
                FROM equipment e
                JOIN device_types dt ON e.device_type_id = dt.device_type_id
                JOIN manufacturers m ON e.manufacturer_id = m.manufacturer_id
                WHERE m.status='active' AND e.manufacturer_id = $mfrId";
        //add specifc device to filter
        if($typeId > 0) $sql .= " AND e.device_type_id = $typeId";
        $results = $dblink->query($sql);
	*/
}
//search by serial #
elseif($mode==='serial') {
	//get sn from input
	$sn=$_REQUEST['sn'] ?? 0;
	//call searching with serial
        $response=callAPI('search_equipment', array('mode'=>'serial','sn'=>$sn));
	//check for succesfull response
	if($response['status']==='Success' && $response['data']!=='none') {
		//store in array
		$results=$response['data'];
        }
        else {
                $error=$response['message'];
        }
	/*
        //escape serial # (sql injection)
        $serial=$dblink->real_escape_string($_REQUEST['serial'] ?? '');
        //only return matching active serial # equipment
        $results=$dblink->query(
                "SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
                FROM equipment e
                JOIN device_types dt ON e.device_type_id = dt.device_type_id
                JOIN manufacturers m ON e.manufacturer_id = m.manufacturer_id
                WHERE e.serial_number='$serial' AND e.status='active'"
	);
	 */
}
/*
//search all 
elseif($mode==='all') {
        //active default
        $filter=$_REQUEST['filter'] ?? 'active';
        //query no status filter
        $sql="SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
                FROM equipment e
                JOIN device_types dt ON e.device_type_id = dt.device_type_id
                JOIN manufacturers m ON e.manufacturer_id = m.manufacturer_id";
        //add status from button
        if($filter==='active') $sql .= " WHERE e.status='active'";
        elseif($filter==='inactive') $sql .= " WHERE e.status='inactive'";
        $results = $dblink->query($sql);
}
 */
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Software Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Search Equipment Database - External</a>
               </div>
               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="index.php"class="smoothScroll">Home</a></li>
                         <li><a href="search.php"class="smoothScroll">Search Equipment</a></li>
                         <li><a href="add.php"class="smoothScroll">Add Equipment</a></li>
                    </ul>
               </div>
          </div>
     </section>
 <!-- HOME -->
     <section id="home">
          </div>
     </section>
     <!-- FEATURE -->
     <section id="feature">
          <div class="container">
               <div class="row">
                <!--device type form-->
                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Search by device type</h3>
                                <form method="GET" action="">
                                        <div class="form-group">
                                                <label>Device Type:</label>
                                                <select name="did" class="form-control">
                                                        <?php foreach($deviceTypes as $r): ?>
                                                                <option value="<?= $r['id'] ?>" <?= (isset($_GET['did']) && $_GET['did'] == $r['id'] && $mode==='type') ? 'selected' : '' ?>>
                                                                        <?= htmlspecialchars($r['name']) ?>
                                                                </option>
                                                        <?php endforeach; ?>
                                                </select>
                                        </div>
                                        <div class="form-group">
                                                <label>Manufacturer:</label>
                                                <!--default is all-->        
                                                <select name="mid" class="form-control">
                                                        <option value="0">All Manufacturers</option>         
                                                        <?php foreach($manufacturers as $r): ?>
                                                                <option value="<?= $r['id'] ?>" <?= (isset($_GET['mid']) && $_GET['mid'] == $r['id'] && $mode==='type') ? 'selected' : '' ?>>               
                                                                        <?= htmlspecialchars($r['name']) ?>
                                                                </option>
                                                        <?php endforeach; ?>
                                                </select>
                                        </div>
                                        <input type="hidden" name="mode" value="type">
                                        <button type="submit" class="btn btn-default">Search</button>
                                </form>
                        </div>
                </div>
                <!--manu form-->
                <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Search by manufacturer</h3>
                                <form method="GET" action="">
                                        <div class="form-group">
                                                <label>Manufacturer:</label>
                                                <select name="mid" class="form-control">
                                                        <?php foreach($manufacturers as $r): ?>
                                                                <option value="<?= $r['id'] ?>" <?= (isset($_GET['mid']) && $_GET['mid'] == $r['id'] && $mode==='manufacturer') ? 'selected' : '' ?>>
                                                                        <?= htmlspecialchars($r['name']) ?>
                                                                </option>
                                                        <?php endforeach; ?>
                                                </select>
                                        </div>
                                        <div class="form-group">
                                                <label>Device Type:</label>
                                                <select name="did" class="form-control"> 
                                                        <option value="0">All Device Types</option>         
                                                        <?php foreach($deviceTypes as $r): ?>
                                                                <option value="<?= $r['id'] ?>" <?= (isset($_GET['did']) && $_GET['did'] == $r['id'] && $mode==='manufacturer') ? 'selected' : '' ?>>             
                                                                        <?= htmlspecialchars($r['name']) ?>
                                                                </option>
                                                        <?php endforeach; ?>
                                                </select>
                                        </div>
                                        <input type="hidden" name="mode" value="manufacturer">
                                        <button type="submit" class="btn btn-default">Search</button>
                                </form>
                        </div>
                </div>
                <!--serial # form-->
                <div class="col-md-4 col-sm-4">
                        <div class="feature-thumb">
                                <h3>Search by serial number</h3>
                                <form method="GET" action="">
                                        <div class="form-group">
                                                <label>Serial Number:</label>
                                                <!--type serial #-->
                                                <input type="text" name="sn" class="form-control" placeholder="SN-..." value="<?= htmlspecialchars($_GET['sn'] ?? '') ?>">
                                        </div>
                                        <input type="hidden" name="mode" value="serial">
                                        <button type="submit" class="btn btn-default">Search</button>
                                </form>
                        </div>
                </div>
                <!--search all form-->
                <div class="col-md-4 col-sm-4">
                        <div class="feature-thumb">
                                <h3>Search All</h3>
                                <form method="GET" action="">
                                        <div class="form-group">
                                        <!--radio buttons, active default-->
                                                <label class="radio-inline">
                                                        <input type="radio" name="filter" value="active" <?= (!isset($_GET['filter']) || $_GET['filter']==='active') ? 'checked' : '' ?>> Active Only
                                                </label>
                                                <label class="radio-inline">
                                                        <input type="radio" name="filter" value="inactive" <?= (isset($_GET['filter']) && $_GET['filter']==='inactive') ? 'checked' : '' ?>> Inactive Only
                                                </label>
                                                <label class="radio-inline">
                                                        <input type="radio" name="filter" value="all" <?= (isset($_GET['filter']) && $_GET['filter']==='all') ? 'checked' : '' ?>> All
                                                </label>
                                        </div>
                                        <input type="hidden" name="mode" value="all">
                                        <button type="submit" class="btn btn-default">Search</button>
                                </form>
                        </div>
                </div>
                <!--results table if query returns rows-->
                <?php if($results && count($results) > 0): ?>
                <div class="col-md-12">
                        <div class="feature-thumb">
                                <h3>Results (<?= count($results) ?> found)</h3>
                                <table class="table table-bordered table-hover">
                                        <thead>
                                                <tr>
                                                        <th>Device ID</th>
                                                        <th>Device Type</th>
                                                        <th>Manufacturer</th>
                                                        <th>Serial Number</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                                <!--loop through results and create a table-->
                                                <?php foreach($results as $row): ?>
                                                <tr>
                                                        <td><?= $row['device_id'] ?></td>
                                                        <td><?= htmlspecialchars($row['type']) ?></td>
                                                        <td><?= htmlspecialchars($row['manufacturer']) ?></td>
                                                        <td><?= htmlspecialchars($row['serial_number']) ?></td>
                                                        <td><?= $row['status'] ?></td>
                                                        <!--view button to view.php-->
                                                        <td><a href="view.php?id=<?= $row['device_id'] ?>" class="btn btn-sm btn-default">VIEW</a></td>
                                                </tr>
                                                <?php endforeach; ?>
                                        </tbody>
                                </table>
                        </div>
                </div>
                <!--no results if query doesnt return anything-->
                <?php elseif ($mode): ?>
                <div class="col-md-12">
                        <div class="alert alert-warning">No results found</div>
                </div>
                <?php endif; ?>

        </div>
</div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
