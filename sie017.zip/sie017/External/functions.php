<?php
//api url
define('API_BASE', 'https://ec2-18-207-93-50.compute-1.amazonaws.com/api/');
//function to call api
function callAPI($endpoint, $data=[]) {
	//initialize curl
	$ch=curl_init(API_BASE . $endpoint);
	//return as string
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	//skip ssl
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	//only if paramaters added
	if(!empty($data)) {
		//curl post request
		curl_setopt($ch, CURLOPT_POST, 1);
		//convert array to string
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	}
	//execute and store results
	$result=curl_exec($ch);
	curl_close($ch);
	return json_decode($result, true);
}
?>
