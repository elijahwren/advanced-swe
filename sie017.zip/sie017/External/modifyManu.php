<?php 
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
//no id in url redirects to search.php
if(!isset($_GET['id'])) {
        header("Location: search.php");
        exit;
}
//get manu id
$id=$_GET['id'];
//hold error or success message
$message='';
//call for manu info
$manufacturersResponse=callAPI('list_manufacturer_types');
$allMfrs=$manufacturersResponse['data'] ?? [];
//find id
$mfr=null;
//loops through manus to find id
foreach($allMfrs as $r) {
	//if a match found
	if($r['id']==$id) {
		//store match
                $mfr=$r;
                break;
        }
}
//if no id, back to index
if(!$mfr) {
        header("Location: index.php");
        exit;
}
//submit changes
if(isset($_POST['submit'])) {
	//get manu from dropdown
	$name=trim($_POST['name'] ?? '');
	//get status
        $status=$_POST['status'] ?? NULL;
        //call to modify
        $response=callAPI('modify_manufacturer', array('id'=>$id,'name'=>$name,'status'=>$status));
        if($response['status']==='Success') {
                $message='<div class="alert alert-success" role="alert">'.$response['message'].'</div>';
                $mfr['name']=$name;
                $mfr['status']=$status;
        }
        else {
                $message='<div class="alert alert-danger" role="alert">'.$response['message'].'</div>';
        }
}
/*
//load current device type
$result=$dblink->query("SELECT * FROM device_types WHERE device_type_id=$id");
//if query failed/no record redirect to search.php
if(!$result || $result->num_rows === 0) redirect("search.php");
//fetch dev type record as array
$dt=$result->fetch_assoc();
//only run if form is submitted
if(isset($_POST['submit'])) {
        //get updated name and trim
        $name=trim($_POST['name']);
        //active or inactive
        $status=$_POST['status'] === 'active' ? 'active' : 'inactive';
        //only letters and spaces
        if(!preg_match('/^[a-zA-Z ]+$/', $name)) {
                $message='<div class="alert alert-danger" role="alert">Only letters and spaces</div>';
        }
        else {
                $escaped=$dblink->real_escape_string($name);
                //check name not being used
                $check=$dblink->query(
                        "SELECT device_type_id FROM device_types WHERE name='$escaped' AND device_type_id != $id"
                );
                if($check->num_rows > 0) {
                        //dupe error message
                        $message='<div class="alert alert-danger" role="alert">Device type already exists</div>';
                }
                else {
                        //unique name update dev type record
                        $dblink->query(
                                "UPDATE device_types SET name='$escaped', status='$status' WHERE device_type_id=$id"
                        );
                        $message='<div class="alert alert-success" role="alert">Device type updated</div>';
                        //reload updated record
                        $result=$dblink->query("SELECT * FROM device_types WHERE device_type_id=$id");
                        $dt=$result->fetch_assoc();
                }
        }
}
*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Sotware Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- menu -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
                <div class="navbar-header">
                        <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand">Modify manufacturer -  External</a>
                </div>
                <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-nav-first">
                                <li><a href="index.php" class="smoothScroll">Home</a></li>
                                <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                                <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                        </ul>
                </div>
        </div>
</section>
<!-- home -->
<section id="home"></section>
<!-- feature-->
<section id="feature">
        <div class="container">
                <div class="row">
                        <div class="col-md-6 col-sm-6">
                                <div class="feature-thumb">
                                        <h3>Modify manufacturer #<?=$id?></h3>
                                        <!--error or success message-->
                                        <?= $message ?>
                                        <form method="post" action="">
                                                <div class="form-group">
                                                        <label>Manufacturer Name:</label>
                                                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($mfr['name']) ?>">
                                                </div>
                                                <div class="form-group">
                                                        <label>Status:</label>
                                                        <!--dropdown selected to current status-->
                                                        <select name="status" class="form-control">
                                                                <option value="active" <?= $mfr['status']==='active' ? 'selected' : '' ?>>Active</option>
                                                                <option value="inactive" <?= $mfr['status']==='inactive' ? 'selected' : '' ?>>Inactive</option>
                                                        </select>
                                                </div>
                                                <button type="submit" class="btn btn-default" name="submit" value="submit">Save</button>
                                                <!--back button to search.php-->
                                                <a href="search.php" class="btn btn-default">Back</a>
                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
