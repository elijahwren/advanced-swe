<?php
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
//no id in url redirects to search.php
if(!isset($_GET['id'])) {
	header("Location: search.php");
	exit;
}
$id=$_GET['id'];
//call to load equipment record
$response=callAPI('view_equipment', array('id'=>$id));
if($response['status']!=='Success') {
	header("Location: search.php");
	exit;
}
$eq=$response['data'];
//call api to get dev types
$deviceTypesResponse=callAPI('list_device_types');
$deviceTypes=$deviceTypesResponse['data'] ?? [];
//call api to get manus
$manufacturersResponse=callAPI('list_manufacturer_types');
$manufacturers=$manufacturersResponse['data'] ?? [];
//hold error or success message
$message='';
/*
$result=$dblink->query(
        "SELECT e.device_id, e.device_type_id, e.manufacturer_id, e.serial_number, e.status
        FROM equipment e
        WHERE e.device_id=$id"
);
//query failed or no record redirect to search.php
if(!$result || $result->num_rows === 0) redirect("search.php");
//fetch equipment as array
$eq=$result->fetch_assoc();
//load active device types into array
$typeResult=$dblink->query("SELECT device_type_id, name FROM device_types WHERE status='active' ORDER BY name");
$deviceTypes=[];
while($r=$typeResult->fetch_assoc())
        $deviceTypes[$r['device_type_id']]=$r['name'];
//load active manus into array
$mfrResult=$dblink->query("SELECT manufacturer_id, name FROM manufacturers WHERE status='active' ORDER BY name");
$manufacturers=[];
while($r=$mfrResult->fetch_assoc())
        $manufacturers[$r['manufacturer_id']]=$r['name'];
 */
//only run if form is submitted
if(isset($_POST['submit'])) {
	//get dev type id from dropdown
	$did=$_POST['did'] ?? NULL;
	//get manu id from dropdown
	$mid=$_POST['mid'] ?? NULL;
	//get updated sn from input
	$sn=trim($_POST['sn'] ?? '');
	//get status
	$status=$_POST['status'] ?? NULL;
	//call to modify equipment
	$response=callAPI('modify_equipment', array('id'=>$id,'did'=>$did,'mid'=>$mid,'sn'=>$sn,'status'=>$status));
	if($response['status']==='Success') {
		$message='<div class="alert alert-success" role="alert">'.$response['message'].'</div>';
		//realod details
		$eq=callAPI('view_equipment', array('id'=>$id))['data'];
	}
	else {
		$message='<div class="alert alert-danger" role="alert">'.$response['message'].'</div>';
	}
}
	/*
        //update values from form
        $typeId=(int)$_POST['device_type_id'];
        $mfrId=(int)$_POST['manufacturer_id'];
        //get serial # and trim
        $serial=trim($_POST['serial_number']);
        //active or inactive
        $status=$_POST['status'] === 'active' ? 'active' : 'inactive';
        //validate serial # format
        if(!preg_match('/^SN-[0-9A-Fa-f]{32,128}$/', $serial)) {
                $message='<div class="alert alert-danger" role="alert">Invalid serial format, between 32-128 characters</div>';
        }
        else {
                //esacpe serial # prevent sql injection
                $escapedSerial=$dblink->real_escape_string($serial);
                //check that serial is unique
                $check=$dblink->query(
                        "SELECT device_id FROM equipment WHERE serial_number='$escapedSerial' and device_id != $id"
                );
                if($check->num_rows > 0) {
                        //dupe serial error
                        $message='<div class="alert alert-danger" role="alert">Serial number already used</div>';
                }
                else {
                        //if unique update equipemnt record
                        $dblink->query(
                                "UPDATE equipment SET device_type_id=$typeId, manufacturer_id=$mfrId,
                                serial_number='$escapedSerial', status='$status'
                                WHERE device_id=$id"
                        );
                        $message='<div class="alert alert-success" role="alert">Equipment updated</div>';
                        //reload updated record
                        $result=$dblink->query("SELECT e.device_id, e.device_type_id, e.manufacturer_id, e.serial_number, e.status FROM equipment e WHERE e.device_id=$id");
                        $eq=$result->fetch_assoc();
                }
        }
}
*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Sotware Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- menu -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
                <div class="navbar-header">
                        <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand">Modify equipment - External</a>
                </div>
                <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-nav-first">
                                <li><a href="index.php" class="smoothScroll">Home</a></li>
                                <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                                <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                        </ul>
                </div>
        </div>
</section>
<!-- home -->
<section id="home"></section>
<!-- feature-->
<section id="feature">
        <div class="container">
                <div class="row">
                        <div class="col-md-6 col-sm-6">
                                <div class="feature-thumb">
                                        <h3>Modify Equipment #<?=$id?></h3>
                                        <!--show error or success message-->
                                        <?= $message ?>
                                        <form method="post" action="">
                                                <div class="form-group">
                                                        <label>Device Type:</label>
                                                        <!--dropdown active dev types-->
                                                        <select name="did" class="form-control">
                                                                <?php foreach($deviceTypes as $r): ?>
                                                                        <option value="<?= $r['id'] ?>" <?= $r['name']=== $eq['type'] ? 'selected' : '' ?>>
                                                                                <?= htmlspecialchars($r['name']) ?>
                                                                        </option>
                                                                <?php endforeach; ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        <label>Manufacturer:</label>
                                                        <!--dropdown active manus-->
                                                        <select name="mid" class="form-control">
                                                                <?php foreach($manufacturers as $r): ?>
                                                                        <option value="<?= $r['id'] ?>" <?= $r['name'] === $eq['manufacturer'] ? 'selected' : '' ?>>
                                                                                <?= htmlspecialchars($r['name']) ?>
                                                                        </option>
                                                                <?php endforeach; ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        <label>Serial number:</label>
                                                        <!--prefilled with current-->
                                                        <input type="text" name="sn" class="form-control" value="<?= htmlspecialchars($eq['serial_number']) ?>">
                                                </div>
                                                <div class="form-group">
                                                        <label>Status:</label>
                                                        <!--dropdown current status-->
                                                        <select name="status" class="form-control">
                                                                <option value="active" <?= $eq['status']==='active' ? 'selected' : '' ?>>Active</option>
                                                                <option value="inactive" <?= $eq['status']==='inactive' ? 'selected' : '' ?>>Inactive</option>
                                                        </select>
                                                </div>
                                                <button type="submit" class="btn btn-primary" name="submit" value="submit">Save</button>
                                                <!--back button to view.php-->
                                                <a href="view.php?id=<?= $id ?>" class="btn btn-default">Back</a>
                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
