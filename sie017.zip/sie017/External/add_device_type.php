<?php
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
//hold error or success message
$message='';
//only run if form was submitted
if(isset($_POST['submit'])) {
        //get dev type and trim
	$name=trim($_POST['name'] ?? '');
	//call api to add dev type
	$response=callAPI('add_device_type', array('name'=>$name));
	//success message
	if($response['status']==='Success') {
		$message='<div class="alert alert-success" role="alert">'.$response['message'].'</div>';
	}
	else {
		$message='<div class="alert alert-danger" role="alert">'.$response['message'].'</div>';
	}
}
	/*
        //only letters and spaces
        if(!preg_match('/^[a-zA-Z ]+$/', $name)) {
                $message='<div class="alert alert-danger" role="alert">Only letters and spaces allowed</div>';
        }
        else {
                //escape for sql injection
                $escaped=$dblink->real_escape_string($name);
                //check if name already exists
                $check=$dblink->query("SELECT device_type_id FROM device_types WHERE name='$escaped'");
                if($check->num_rows>0) {
                        //dupe error
                        $message='<div class="alert alert-danger" role="alert">Device type already exists</div>';
                }
                else {
                        //if unique insert into dev types
                        $dblink->query("INSERT INTO device_types (name, status) VALUES ('$escaped', 'active')");
                        $message='<div class="alert alert-success" role="alert">Device type added</div>';
                }
        }
}
*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Sotware Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- menu -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
                <div class="navbar-header">
                        <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand">Add Device Type - External</a>
                </div>
                <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-nav-first">
                                <li><a href="index.php" class="smoothScroll">Home</a></li>
                                <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                                <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                        </ul>
                </div>
        </div>
</section>
<!-- home -->
<section id="home"></section>
<!-- feature-->
<section id="feature">
        <div class="container">
                <div class="row">
                        <div class="col-md-6 col-sm-6">
                                <div class="feature-thumb">
                                        <h3>Add New Device Type</h3>
                                        <!--display error or success message-->
                                        <?= $message ?>
                                        <form method="post" action="">
                                                <div class="form-group">
                                                        <label>Device type name:</label>
                                                        <!--text input for dev type-->
                                                        <input type="text" class="form-control" name="name" placeholder="e.g., tablet">
                                                </div>
                                                <button type="submit" class="btn btn-default" name="submit" value="submit">Add device type</button>
                                                <!--back returns to add.php-->
                                                <a href="add.php" class="btn btn-default">Back</a>
                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
