<?php
$ch=curl_init("https://ec2-18-207-93-50.compute-1.amazonaws.com/api/list_device_types");
$data="test";
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
curl_setopt($ch,CURLOPT_POST,1);
curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_HTTPHEADER, array(
	'content-type: application/x-www-form-urlencoded',
	'content-length: '.strlen($data)));
$result=curl_exec($ch);
curl_close($ch);
echo $result;
?>
