<?php
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Software Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">AES Inventory Database - External</a>
               </div>
               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="index.php" class="smoothScroll">Home</a></li>
                         <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                         <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                    </ul>
               </div>
          </div>
     </section>
 <!-- HOME -->
     <section id="home">
          </div>
     </section>
     <!-- FEATURE -->
     <section id="feature">
          <div class="container">
               <div class="row">
                   <?php
                    if (isset($_REQUEST['msg']) && $_REQUEST['msg']=="EquipmentAdded")
                    {
                        echo '<div class="alert alert-success" role="alert">Equipment successfully added.</div>';
		    }
			//call to get dev types
			$deviceTypesResponse=callAPI('list_device_types');
			$deviceTypes=$deviceTypesResponse['data'] ?? [];
			//call to get manus
			$manufacturersResponse=callAPI('list_manufacturer_types');
			$manufacturers=$manufacturersResponse['data'] ?? [];
                    ?>
			<p>EXTERNAL!!!</p>
                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Search Equipment</h3>
                              <p>Click here to search the equipment database.</p>
                              <a href="search.php" class="btn btn-default smoothScroll">Discover more</a>
                         </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Add Equipment</h3>
                              <p>Click here to add new equipment</p>
                             <a href="add.php" class="btn btn-default smoothScroll">Discover more</a>
                         </div>
                    </div>
                        <!--modify device type table-->
                        <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Device Types</h3>
                                <table class="table table-bordered">
                                        <thead>
                                                <tr>
                                                        <th>Name</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
						<?php foreach($deviceTypes as $r): ?>
                                                <tr>
                                                        <td><?= htmlspecialchars($r['name']) ?></td>
                                                        <td>active</td>
                                                        <!--modify button to modify_device_type.php-->
                                                        <td><a href="modify_device_type.php?id=<?= $r['id'] ?>" class="btn btn-default">Modify</a></td>
                                                </tr>
                                                <?php endforeach; ?>
                                        </tbody>
                                </table>
                        </div>
                </div>
                <!--modify manu table-->
                <div class="col-md-4 col-sm-4">
                         <div class="feature-thumb">
                              <h3>Manufacturers</h3>
                                <table class="table table-bordered">
                                        <thead>
                                                <tr>
                                                        <th>Name</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                </tr>
                                        </thead>
                                        <tbody>
						<?php foreach($manufacturers as $r): ?>
                                                <tr>
                                                        <td><?= htmlspecialchars($r['name']) ?></td>
                                                        <td>active</td>
                                                        <!--modify button to modifyManu.php-->
                                                        <td><a href="modifyManu.php?id=<?= $r['id'] ?>" class="btn btn-default">Modify</a></td>
                                                </tr>
                                                <?php endforeach; ?>
                                        </tbody>
                                </table>
                        </div>
               </div>
          </div>
     </section>
</body>
</html>
