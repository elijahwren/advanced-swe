<?php
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
//load active device types in array
/*
$typeResult=$dblink->query("SELECT device_type_id, name FROM device_types WHERE status='active' ORDER BY name");
$deviceTypes=[];
while($r=$typeResult->fetch_assoc())
        $deviceTypes[$r['device_type_id']]=$r['name'];
//load active manus in array
$mfrResult=$dblink->query("SELECT manufacturer_id, name FROM manufacturers WHERE status='active' ORDER BY name");
$manufacturers=[];
while($r=$mfrResult->fetch_assoc())
        $manufacturers[$r['manufacturer_id']]=$r['name'];
//holds error or success messages
$message='';
 */
//call to get dev types
$deviceTypesResponse=callAPI('list_device_types');
$deviceTypes=$deviceTypesResponse['data'] ?? [];
//call to get manus
$manufacturersResponse=callAPI('list_manufacturer_types');
$manufacturers=$manufacturersResponse['data'] ?? [];
$message='';
//only runs if form was submitted
if(isset($_POST['submit'])) {
	//get dev type from dropdown
	$did=$_POST['did'] ?? NULL;
	//get manu from dropdown
	$mid=$_POST['mid'] ?? NULL;
	//get sn from input
	$sn=trim($_POST['serialnumber'] ?? '');
	//call to add equipment
	$response=callAPI('add_equipment', array('did'=>$did,'mid'=>$mid,'sn'=>$sn));
	if($response['status']==='Success') {
		header("Location: index.php?msg=EquipmentAdded");
		exit;
	}
	else {
		$message='<div class="alert alert-danger" role="alert">'.$response['message'].'</div>';
	}
}
	/*
	//get dev type and manu ID from dropdowns
        $typeId=(int)$_POST['device_type_id'];
        $mfrId=(int)$_POST['manufacturer_id'];
        //get serial # and trim
        $serial=trim($_POST['serialnumber']);
        //validate serial # format
        if(!preg_match('/^SN-[0-9A-Fa-f]{32,128}$/', $serial)) {
                $message='<div class="alert alert-danger" role="alert">Invalid serial number format</div>';
        }
        else {
                //escape serial # (sql injection)
                $escapedSerial=$dblink->real_escape_string($serial);
                //check for dupe serial #
                $check=$dblink->query("SELECT device_id FROM equipment WHERE serial_number='$escapedSerial'");
                if($check->num_rows > 0) {
                        //dupe error
                        $message='<div class="alert alert-danger" role="alert">Serial number already exists in db</div>';
                } else {
                        //insert unique serial into equipment
                        $dblink->query("INSERT INTO equipment (device_type_id, manufacturer_id, serial_number, status)
                                        VALUES ($typeId, $mfrId, '$escapedSerial', 'active')");
                        //redirect success message
                        redirect("index.php?msg=EquipmentAdded");
                }
        }
}
*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Software Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

<!-- MAIN CSS -->
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">
               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Add New Equipment -  External</a>
               </div>
               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="index.php" class="smoothScroll">Home</a></li>
                         <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                         <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                    </ul>
               </div>
          </div>
     </section>
 <!-- HOME -->
     <section id="home">
          </div>
     </section>
     <!-- FEATURE -->
     <section id="feature">
          <div class="container">
               <div class="row">
                        <div class="col-md-6 col-sm-6">
                                <div class="feature-thumb">
                                        <h3>Add new equipment</h3>
                                        <!--success or error message-->
                                        <?= $message ?>
                                        <form method="post" action="">
                                                <div class="form-group">
                                                        <label>Device Type:</label>
                                                        <!--dropdown-->
                                                        <select class="form-control" name="did">
                                                                <?php foreach($deviceTypes as $r): ?>
                                                                        <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name'])?></option>
                                                                <?php endforeach; ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        <label>Manufacturer:</label>
                                                        <!--dropdown-->
                                                        <select class="form-control" name="mid">
                                                                <?php foreach($manufacturers as $r): ?>
                                                                        <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name'])?></option>                                              
                                                                <?php endforeach; ?>
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        <label>Serial Number:</label>
                                                        <!--text input serial #-->
                                                        <input type="text" class="form-control" name="serialnumber" placeholder="SN-...">
                                                </div>
                                                <button type="submit" class="btn btn-default" name="submit" value="submit">Add Equipment</button>
                                        </form>
                                </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                                <!--routes-->
                                <div class="feature-thumb">
                                        <h3>Add New Device Type</h3>
                                        <a href="add_device_type.php" class="btn btn-default">Add Device Type</a>
                                </div>
                                <div class="feature-thumb">
                                        <h3>Add New Manufacturer</h3>
                                        <a href="addManu.php" class="btn btn-default">Add New Manufacturer</a>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
