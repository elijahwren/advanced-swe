<?php
include("functions.php");
//connect to db
//$dblink = db_connect("equipment");
//no id in url goes back to search
if(!isset($_GET['id'])) {
	header("Location: search.php");
	exit;
}
//id to integer prevent sql injection
$id=(int)$_GET['id'];
//call api to get details
$response=callAPI('view_equipment', array('id'=>$id));
//query equipment joining dev types and manus
/*$result=$dblink->query(
        "SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
        FROM equipment e
        JOIN device_types dt ON e.device_type_id=dt.device_type_id
        JOIN manufacturers m ON e.manufacturer_id=m.manufacturer_id
        WHERE e.device_id=$id"
);
 */
//no result redirect to search
if($response['status']!=='Success') {
	header("Location: search.php");
	exit;
}
//fetch equipment as array
//$eq=$result->fetch_assoc();
$eq=$response['data'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Software Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- menu -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
                <div class="navbar-header">
                        <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand">View Equipment - External</a>
                </div>
                <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-nav-first">
                                <li><a href="index.php" class="smoothScroll">Home</a></li>
                                <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                                <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                        </ul>
                </div>
        </div>
</section>
<!-- home -->
<section id="home">
</section>
<!-- feature -->
<section id="feature">
        <div class="container">
                <div class="row">
                        <div class="col-md-8 col-sm-8">
                                <div class="feature-thumb">
                                        <h3>Equipment Details</h3>
                                        <!--display 5 equipment attributes-->
                                        <table class="table table-bordered">
                                                <tr>
                                                        <th>Device ID</th>
                                                        <td><?= $eq['device_id'] ?></td>
                                                </tr>
                                                <tr>
                                                        <th>Device Type</th>
                                                        <td><?= htmlspecialchars($eq['type']) ?></td>
                                                </tr>
                                                <tr>
                                                        <th>Manufacturer</th>
                                                        <td><?= htmlspecialchars($eq['manufacturer']) ?></td>
                                                </tr>
                                                <tr>
                                                        <th>Serial Number</th>
                                                        <td><?= htmlspecialchars($eq['serial_number']) ?></td>
                                                </tr>
                                                <tr>
                                                        <th>Status</th>
                                                        <td><?= $eq['status'] ?></td>
                                                </tr>
                                        </table>
                                        <!--modify button to modify_equipment.php-->
                                        <a href="modifyEquipment.php?id=<?= $eq['device_id'] ?>" class="btn btn-default">Modify</a>
                                        <!--back returns to search-->
                                        <a href="search.php" class="btn btn-default">Back to Search</a>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
