<?php
include("functions.php");
//connect to db
//$dblink=db_connect("equipment");
//holds error success messages
$message='';
//only runs if submitted
if(isset($_POST['submit'])) {
        //get manu name and trim
	$name=trim($_POST['name'] ?? NULL);
	//call to add manu
	$response=callAPI('add_manufacturer', array('name'=>$name));
	if($response['status']==='Success') {
		$message='<div class="alert alert-success" role="alert">'.$response['message'].'</div>';
	}
	else {
		$message='<div class="alert alert-danger" role="alert">'.$response['message'].'</div>';
	}
}
	/*
        //only letters and spaces
        if(!preg_match('/^[a-zA-Z]+$/', $name)) {
                $message='<div class="alert alert-danger" role="alert">Only letters and spaces allowed</div>';
        }
        else {
                //escape name prevent sql injection
                $escaped=$dblink->real_escape_string($name);
                //check if name already exists
                $check=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE name='$escaped'");
                if($check->num_rows>0) {
                        //error message
                        $message='<div class="alert alert-danger" role="alert">Manufacturer already exists</div>';
                }
                else {
                        //insert unique manu as active
                        $dblink->query("INSERT INTO manufacturers (name, status) VALUES ('$escaped', 'active')");
                        $message='<div class="alert alert-success" role="alert">Manufacturer added</div>';
                }
        }
}
*/
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Advanced Sotware Engineering - External</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/templatemo-style.css">
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- menu -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
                <div class="navbar-header">
                        <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                                <span class="icon icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand">Add Manufacturer - External</a>
                </div>
                <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-nav-first">
                                <li><a href="index.php" class="smoothScroll">Home</a></li>
                                <li><a href="search.php" class="smoothScroll">Search Equipment</a></li>
                                <li><a href="add.php" class="smoothScroll">Add Equipment</a></li>
                        </ul>
                </div>
        </div>
</section>
<!-- home -->
<section id="home"></section>
<!-- feature-->
<section id="feature">
        <div class="container">
                <div class="row">
                        <div class="col-md-6 col-sm-6">
                                <div class="feature-thumb">
                                        <h3>Add New Manufacturer</h3>
                                        <!--show message-->
                                        <?= $message ?>
                                        <form method="post" action="">
                                                <div class="form-group">
                                                        <label>Manufacturer name:</label>
                                                        <!--text input for manu-->
                                                        <input type="text" class="form-control" name="name" placeholder="e.g., Dell">
                                                </div>
                                                <button type="submit" class="btn btn-default" name="submit" value="submit">Add manufacturer</button>
                                                <!--back button returns to add.php-->
                                                <a href="add.php" class="btn btn-default">Back</a>
                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</section>
<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
