<?php
function db_connect($dbname) {
        $un="webuser";
        $pw="WXWT-56tukLqmINU";
        $host="localhost";
        //create mysql connection
	$dblink=new mysqli($host,$un,$pw,$dbname);//ODBC
        if ($dblink->connect_error) {
                logAndNotify();
        }
        return $dblink;
}
function api_connect($dbname) {
        $un="webuser";
        $pw="WXWT-56tukLqmINU";
        $host="localhost";
        //create mysql connection
        $dblink=new mysqli($host,$un,$pw,$dbname);//ODBC
        if ($dblink->connect_error) {
                logAndNotify();
        }
        return $dblink;
}
function logAndNotify() {
	$output=array("status"=>"Error","message"=>"Database Server not responding","data"=>"");
	$responseData=json_encode($output);
	echo $responseData;
	die();
}
function redirect($url) {
        header("Location: $url");
        exit;
}
?>
