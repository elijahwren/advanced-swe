<?php
include("../functions.php");
//$url=$_SERVER['REQUEST_URI'];
$client=$_SERVER['REMOTE_ADDR'];

header('Content-Type: application/json');
header('HTTP/1.1 200 OK');
/*
$output[]='Status: ERROR';
$output[]='MSG: System Disabled';
$output[]='Action: None';
 */
$url=strtok($_SERVER['REQUEST_URI'], '?');
$tmp1=explode("/",trim($url,"/"));
$method=$_SERVER['REQUEST_METHOD'];
//current endpoint being requested
$endPoint=$tmp1[1];
//temporary debug
//echo json_encode(array("url"=>$url,"parts"=>$tmp1,"endpoint"=>$endPoint));
//die();
//$tmp=array("status"=>"Success","message"=>"Hello World!","data"=>$tmp1[1],"method"=>$method);
//$output=json_encode($tmp);
//echo $output;
//log_error($_SERVER['REMOTE_ADDR'],"SYSTEM DISABLED","SYSTEM DISABLED: $endPoint",$url,"api.php");
switch($endPoint) {
	case "list_device_types":
		include("listDevices.php");
		break;
	case "list_manufacturer_types":
                include("listManufacturers.php");
                break;
	case "add_equipment":
		$did=$_REQUEST['did'];
		$mid=$_REQUEST['mid'];
		$sn=$_REQUEST['sn'];
		include("add_equipment.php");
		break;
	case "add_device_type":
		$name=$_REQUEST['name'] ?? NULL;
		include("add_device_type.php");
		break;
	case "add_manufacturer":
		$name=$_REQUEST['name'] ?? NULL;
		include("addManufacturer.php");
		break;
	case "search_equipment":
		include("searchEquipment.php");
		break;
	case "view_equipment":
		$id=$_REQUEST['id'] ?? NULL;
		include("viewEquipment.php");
		break;
	case "modify_equipment":
		$id=$_REQUEST['id'] ?? NULL;
		include("modifyEquipment.php");
		break;
	case "modify_manufacturer":
		$id=$_REQUEST['id'] ?? NULL;
		include("modifyManu.php");
		break;
	case "modify_device_type":
		$id=$_REQUEST['id'] ?? NULL;
		include("modify_device_type.php");
		break;
	default:
		$output=array("status"=>"Error","message"=>"Invalid/Unknown Endpoint Requested","data"=>"");
		$responseData=json_encode($output);
		echo $responseData;
		break;
}

//--------------------------------------------------------------------------
/*
$url=$_SERVER['REQUEST_URI'];
$path = parse_url($url, PHP_URL_PATH);
$pathComponents = explode("/", trim($path, "/"));
$endPoint=$pathComponents[1];
switch($endPoint)
{
    case "add_equipment":
        $did=$_REQUEST['did'];
        $mid=$_REQUEST['mid'];
        $sn=$_REQUEST['sn'];
        include("add_equipment.php");
        break;
    default:
        header('Content-Type: application/json');
        header('HTTP/1.1 200 OK');
        $output[]='Status: ERROR';
        $output[]='MSG: Invalid or missing endpoint';
        $output[]='Action: None';
        $responseData=json_encode($output);
        echo $responseData;
        break;
}
*/
die();
?>
