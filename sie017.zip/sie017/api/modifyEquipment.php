<?php
//check for equipment id
if($id==NULL || !isset($_REQUEST['id'])) {
	$output=array("status"=>"Error","message"=>"invalid or missing equipment id","data"=>"none");
	echo json_encode($output);
	die();
}
$id=(int)$id;
//get values
$did=$_REQUEST['did'] ?? NULL;
$mid=$_REQUEST['mid'] ?? NULL;
$sn=$_REQUEST['sn'] ?? NULL;
$status=$_REQUEST['status'] ?? NULL;
//check for dev type id
if($did==NULL) {
	$output=array("status"=>"Error","message"=>"missing device type id","data"=>"none");
	echo json_encode($output);
	die();
}
//check for manu id
if($mid==NULL) {
        $output=array("status"=>"Error","message"=>"missing manufacturer id","data"=>"none");
        echo json_encode($output);
        die();
}
//check for serial #
if($sn==NULL) {
        $output=array("status"=>"Error","message"=>"missing serial number","data"=>"none");
        echo json_encode($output);
        die();
}
//check for status
if($status==NULL) {
        $output=array("status"=>"Error","message"=>"missing status","data"=>"none");
        echo json_encode($output);
        die();
}
//validate serial # format
if(!preg_match('/^SN-[0-9A-Fa-f]{32,128}$/', $sn)) {
	$output=array("status"=>"Error","message"=>"invalid serial format","data"=>"none");
	echo json_encode($output);
	die();
}
//force active or inactive 
if($status !== 'active' && $status !== 'inactive') {
	$output=array("status"=>"Error","message"=>"invalid status","data"=>"none");
	echo json_encode($output);
	die();
}
$typeId=(int)$did;
$mfrId=(int)$mid;
$dblink=db_connect("equipment");
$escapedSn=$dblink->real_escape_string($sn);
//check if record exists
$check=$dblink->query("SELECT device_id FROM equipment WHERE device_id=$id");
if($check->num_rows===0) {
	$output=array("status"=>"Error","message"=>"no equipment with id $id","data"=>"none");
	echo json_encode($output);
	die();
}
//check dev type exists and active
$checkType=$dblink->query("SELECT device_type_id FROM device_types WHERE device_type_id=$typeId AND status='active'");
if($checkType->num_rows===0) {
        $output=array("status"=>"Error","message"=>"invalid or inactive device type id","data"=>"none");
        echo json_encode($output);
        die();
}
//check manu exists and active
$checkMfr=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE manufacturer_id=$mfrId AND status='active'");
if($checkMfr->num_rows===0) {
        $output=array("status"=>"Error","message"=>"invalid or inactive manufacturer id","data"=>"none");
        echo json_encode($output);
        die();
}
//check serial is unique
$checkSn=$dblink->query("SELECT device_id FROM equipment WHERE serial_number='$escapedSn' AND device_id != $id");
if($checkSn->num_rows>0) {
        $output=array("status"=>"Error","message"=>"serial number already in use","data"=>"none");
        echo json_encode($output);
        die();
}
//update record
$dblink->query(
	"UPDATE equipment SET device_type_id=$typeId, manufacturer_id=$mfrId, serial_number='$escapedSn', status='$status' WHERE device_id=$id"
);
$output=array("status"=>"Success","message"=>"equipment $id updated","data"=>"none");
echo json_encode($output);
?>
