<?php
//get search mode
$mode=$_REQUEST['mode'] ?? NULL;
//check for missing mode
if($mode==NULL) {
	$output=array("status"=>"Error","message"=>"missing search requirement","data"=>"none");
	echo json_encode($output);
	die();
}
$dblink=db_connect("equipment");
//dev type search
if($mode==='type') {
	$typeId=(int)($_REQUEST['did'] ?? 0);
	$mfrId=(int)($_REQUEST['mid'] ?? 0);
	//if 0, no id 
	if($typeId===0) {
		$output=array("status"=>"Error","message"=>"invalid or missing device type id","data"=>"none");
		echo json_encode($output);
		die();
	}
	//check dev type exists
	$checkType=$dblink->query("SELECT device_type_id FROM device_types WHERE device_type_id=$typeId AND status='active'");
	if($checkType->num_rows===0) {
		$output=array("status"=>"Error","message"=>"invalid device type id","data"=>"none");
		echo json_encode($output);
		die();
	}
	//joining equipment to dev type and manus
	$sql="SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
		FROM equipment e JOIN device_types dt ON e.device_type_id=dt.device_type_id JOIN manufacturers m ON e.manufacturer_id=m.manufacturer_id WHERE e.device_type_id=$typeId";
	//manu filter if 0 = all manus
	if($mfrId>0) $sql .= " AND e.manufacturer_id=$mfrId";
	//1000 result limit
	$sql .= " Limit 1000";
	$result=$dblink->query($sql);
	//no results returned
	if($result->num_rows===0) {
		$output=array("status"=>"Success","message"=>"no results","data"=>"none");
		echo json_encode($output);
		die();
	}
	//loop through and build array
	$info=[];
	while($data=$result->fetch_assoc())
		$info[]=array(
			"device_id"=>$data['device_id'],
			"type"=>$data['type'],
			"manufacturer"=>$data['manufacturer'],
			"serial_number"=>$data['serial_number'],
			"status"=>$data['status']
		);
	//successful return
	$output=array("status"=>"Success","message"=>"found " .$result->num_rows." records","data"=>$info);
	echo json_encode($output);
}
//search by manu
elseif($mode==='manufacturer') {
	$mfrId=(int)($_REQUEST['mid'] ?? 0);
        $typeId=(int)($_REQUEST['did'] ?? 0);
        //check for missing id
        if($mfrId===0) {
                $output=array("status"=>"Error","message"=>"invalid or missing manufacturer id","data"=>"none");
                echo json_encode($output);
                die();
        }
        //check manu exists
        $checkMfr=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE manufacturer_id=$mfrId AND status='active'");
        if($checkMfr->num_rows===0) {
                $output=array("status"=>"Error","message"=>"invalid or inactive manufacturer id","data"=>"none");
                echo json_encode($output);
                die();
        }
        //
        $sql="SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
                FROM equipment e JOIN device_types dt ON e.device_type_id=dt.device_type_id JOIN manufacturers m ON e.manufacturer_id=m.manufacturer_id WHERE e.manufacturer_id=$mfrId";
        //dev type filter if 0 = all manus
        if($typeId>0) $sql .= " AND e.device_type_id=$typeId";
        //1000 result limit
        $sql .= " Limit 1000";
	$result=$dblink->query($sql);
	//if 0, no id
        if($result->num_rows===0) {
                $output=array("status"=>"Success","message"=>"no results found","data"=>"none");
                echo json_encode($output);
                die();
	}
	//loop through and build array
        $info=[];
        while($data=$result->fetch_assoc())
                $info[]=array(
                        "device_id"=>$data['device_id'],
                        "type"=>$data['type'],
                        "manufacturer"=>$data['manufacturer'],
                        "serial_number"=>$data['serial_number'],
                        "status"=>$data['status']
		);
	//successful return
        $output=array("status"=>"Success","message"=>"found " .$result->num_rows." records","data"=>$info);
        echo json_encode($output);
}
//search by serial
elseif($mode==='serial') {
	$sn=$_REQUEST['sn'] ?? NULL;
	//check for missing serial
	if($sn==NULL) {
		$output=array("status"=>"Error","message"=>"missing serial #","data"=>"none");
		echo json_encode($output);
		die();
	}
	$escapedSn=$dblink->real_escape_string($sn);
	$result=$dblink->query(
		"SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status
		FROM equipment e JOIN device_types dt ON e.device_type_id=dt.device_type_id JOIN manufacturers m ON e.manufacturer_id=m.manufacturer_id WHERE e.serial_number='$escapedSn' LIMIT 1000"
	);
	//no results
	if($result->num_rows===0) {
		$output=array("status"=>"Success","message"=>"no resutls found","data"=>"none");
		echo json_encode($output);
		die();
	}
	//loop through and build array
	$info=[];
        while($data=$result->fetch_assoc())
                $info[]=array(
                        "device_id"=>$data['device_id'],
                        "type"=>$data['type'],
                        "manufacturer"=>$data['manufacturer'],
                        "serial_number"=>$data['serial_number'],
                        "status"=>$data['status']
		);
	//successful return
        $output=array("status"=>"Success","message"=>"found " .$result->num_rows." records","data"=>$info);
        echo json_encode($output);
}
else {
	//invalid search mode
	$output=array("status"=>"Error","message"=>"invalid search param use type, manu, or sn","data"=>"none");
	echo json_encode($output);
}
?>
