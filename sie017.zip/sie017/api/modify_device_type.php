<?php
//check for id
if($id==NULL || !isset($_REQUEST['id'])) {
	$output=array("status"=>"Error","message"=>"invalid or missing device type id","data"=>"none");
	echo json_encode($output);
	die();
}
$id=(int)$id;
//get updated values
$name=$_REQUEST['name'] ?? NULL;
$status=$_REQUEST['status'] ?? NULL;
//check for name
if($name==NULL) {
	$output=array("status"=>"Error","message"=>"missing device type name","data"=>"none");
	echo json_encode($output);
	die();
}
//check for status 
if($status==NULL) {
        $output=array("status"=>"Error","message"=>"missing status","data"=>"none");
        echo json_encode($output);
        die();
}
//validate name
if(!preg_match('/^[a-z ]+$/', $name)) {
	$output=array("status"=>"Error","message"=>"invalid characters only lowercase letters and spaces","data"=>"none");
	echo json_encode($output);
	die();
}
//force active or inactive
if($status !== 'active' && $status !== 'inactive') {
	$output=array("status"=>"Error","message"=>"invalid status","data"=>"none");
	echo json_encode($output);
	die();
}
$dblink=db_connect("equipment");
$escaped=$dblink->real_escape_string($name);
//check dev type exists
$check=$dblink->query("SELECT device_type_id FROM device_types WHERE device_type_id=$id");
if($check->num_rows===0) {
	$output=array("status"=>"Error","message"=>"no device type with $id","data"=>"none");
	echo json_encode($output);
	die();
}
//check name not in use
$checkName=$dblink->query("SELECT device_type_id FROM device_types WHERE name='$escaped' AND device_type_id != $id");
if($checkName->num_rows>0) {
        $output=array("status"=>"Error","message"=>"device type'$name' exists already","data"=>"none");
        echo json_encode($output);
        die();
}
//update dev type
$dblink->query("UPDATE device_types SET name='$escaped', status='$status' WHERE device_type_id=$id");
$output=array("status"=>"Success","message"=>"device type $id updated","data"=>"none");
echo json_encode($output);
?>
