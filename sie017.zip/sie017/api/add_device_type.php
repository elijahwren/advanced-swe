<?php
//check for no dev type
if($name==NULL || !isset($_REQUEST['name'])) {
	$output=array("status"=>"Error","message"=>"missing device tyep","data"=>"none");
	echo json_encode($output);
	die();
}
//validating for correct device name
if(!preg_match('/^[a-z ]+$/', $name)) {
	$output=array("status"=>"Error","message"=>"invalid, only lowercase letters and spaces","data"=>"none");
	echo json_encode($output);
	die();
}
$dblink=db_connect("equipment");
$escaped=$dblink->real_escape_string($name);
//check if name exists
$check=$dblink->query("SELECT device_type_id FROM device_types WHERE name='$escaped'");
if($check->num_rows>0) {
	$output=array("status"=>"Error","message"=>"device type '$name' exists already","data"=>"none");
	echo json_encode($output);
	die();
}
//insert new as active
$dblink->query("INSERT INTO device_types (name, status) VALUES ('$escaped', 'active')");
$output=array("status"=>"Success","message"=>"device type '$name' added","data"=>"none");
echo json_encode($output);
?>
