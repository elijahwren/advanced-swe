<?php
if ($did==NULL || !isset($_REQUEST['did']))//decive id is missing
{
	$output=array("status"=>"Error","message"=>"Invalid or missing device id","data"=>"list_device_types");
	/*
	header('Content-Type: application/json');
    	header('HTTP/1.1 200 OK');
    	$output['status']='Error';
    	$output['message']='Invalid or missing device id.';
    	$output['data']='list_devices';
    	$responseData=json_encode($output);
	echo $responseData;
	 */
	echo json_encode($output);
    	die();
}
if ($mid==NULL || !isset($_REQUEST['mid']))//missing manufacturer id
{
	$output=array("status"=>"Error","message"=>"Invalid or missing manufacturer id","data"=>"list_manufacturers_types");
	/*
	header('Content-Type: application/json');
    	header('HTTP/1.1 200 OK');
    	$output['status']='Error';
    	$output['message']='Invalid or missing manufacturer id.';
    	$output['data']='list_manufacturer';
    	$responseData=json_encode($output);
	echo $responseData;
	 */
	echo json_encode($output);
	die();
}
if ($sn==NULL || !isset($_REQUEST['sn']))//missing serial number
{
	$output=array("status"=>"Error","message"=>"Invalid or missing serial number","data"=>"SN-xxxx");
	/*
	header('Content-Type: application/json');
    	header('HTTP/1.1 200 OK');
    	$output['status']='Error';
    	$output['message']='Invalid or missing serial number.';
    	$output['data']='SN-xxxxxxxxxxx';
    	$responseData=json_encode($output);
	echo $responseData;
	 */
	echo json_encode($output);
	die();
}
//validate serial format
if(!preg_match('/^SN-[0-9A-Fa-f]{32,128}$/', $sn)) {
	$output=array("status"=>"Error","message"=>"Invalid serial format","data"=>"none");
	echo json_encode($output);
	die();
}
$typeId=(int)$did;
$mfrId=(int)$mid;
$dblink=db_connect("equipment");
$escapedSerial=$dblink->real_escape_string($sn);
//check for dupe seriial #
$check=$dblink->query("SELECT device_id FROM equipment WHERE serial_number='$escapedSerial'");
if($check->num_rows>0) {
	$output=array("status"=>"Error","message"=>"Serial number already exists","data"=>"none");
	echo json_encode($output);
	die();
}
//check dev type and active
$checkType=$dblink->query("SELECT device_type_id FROM device_types WHERE device_type_id=$typeId AND status='active'");
if($checkType->num_rows===0) {
	$output=array("status"=>"Error","message"=>"Invalid or inactive device type id","data"=>"list_device_types");
	echo json_encode($output);
	die();
}
//check manu and active
$checkMfr=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE manufacturer_id=$mfrId AND status='active'");
if($checkMfr->num_rows===0) {
        $output=array("status"=>"Error","message"=>"Invalid or inactive manufacturer id","data"=>"list_manufacturer_types");
        echo json_encode($output);
        die();
}
//insert new record
$sql="INSERT INTO equipment (device_type_id, manufacturer_id, serial_number, status) VALUES ($typeId, $mfrId, '$escapedSerial', 'active')";
$dblink->query($sql) or 
	die("Something went wrong with");
$output=array("status"=>"Success","message"=>"$sn added to db","data"=>"none");
echo json_encode($output);
/*
$output['status']='Success';
$output['message']="$sn added to db";
$output['data']='none';
$responseData=json_encode($output);
echo $responseData;
 */
?>
