<?php
//check for manu
if($name==NULL || !isset($_REQUEST['name'])) {
        $output=array("status"=>"Error","message"=>"missing manufacturer","data"=>"none");
        echo json_encode($output);
        die();
}
//validating for correct manu name
if(!preg_match('/^[A-Z][a-zA-Z]*$/', $name)) {
        $output=array("status"=>"Error","message"=>"invalid, only letters allowed, must start uppercase","data"=>"none");
        echo json_encode($output);
        die();
}
$dblink=db_connect("equipment");
$escaped=$dblink->real_escape_string($name);
//check if name exists
$check=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE name='$escaped'");
if($check->num_rows>0) {
        $output=array("status"=>"Error","message"=>"Manufacturer '$name' exists already","data"=>"none");
        echo json_encode($output);
        die();
}
//insert new as active
$dblink->query("INSERT INTO manufacturers (name, status) VALUES ('$escaped', 'active')");
$output=array("status"=>"Success","message"=>"manufacturerx '$name' added","data"=>"none");
echo json_encode($output);
?>
