<?php
//check for missing id
if($id==NULL || !isset($_REQUEST['id'])) {
	$output=array("status"=>"Error","message"=>"invalid or missing equipment id","data"=>"none");
	echo json_encode($output);
	die();
}
$id=(int)$id;
$dblink=db_connect("equipment");
//query to join dev types and manus
$result=$dblink->query(
	"SELECT e.device_id, dt.name AS type, m.name AS manufacturer, e.serial_number, e.status FROM equipment e JOIN device_types dt ON e.device_type_id=dt.device_type_id JOIN manufacturers m ON e.manufacturer_id=m.manufacturer_id WHERE e.device_id=$id"
);
//check if found
if(!$result || $result->num_rows===0) {
	$output=array("status"=>"Error","message"=>"no equipment with id $id","data"=>"none");
	echo json_encode($output);
	die();
}
$data=$result->fetch_assoc();
//return all atributes
$info=array(
	"device_id"=>$data['device_id'],
	"type"=>$data['type'],
	"manufacturer"=>$data['manufacturer'],
	"serial_number"=>$data['serial_number'],
	"status"=>$data['status']
);
$output=array("status"=>"Success","message"=>"equipment found","data"=>$info);
echo json_encode($output);
?>
