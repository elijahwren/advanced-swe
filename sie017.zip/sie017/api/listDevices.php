<?php
//include("../functions.php");
$dblink=db_connect("equipment");
//$sql="SELECT DISTINCT(`name`) FROM `device_types`";
$sql="SELECT device_type_id, name FROM device_types WHERE status='active' ORDER BY name";
$result=$dblink->query($sql) or
	die("Something went wrong with $sql");
//count records found
$count=$result->num_rows;
$info=[];
while($data=$result->fetch_assoc())
	$info[]=array("id"=>$data['device_type_id'],"name"=>$data['name']);;
$output=array("status"=>"Success","message"=>"Found $count records","data"=>$info);
$responseData=json_encode($output);
echo $responseData;
?>
