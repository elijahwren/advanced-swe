<?php
//check for id
if($id==NULL || !isset($_REQUEST['id'])) {
	$output=array("status"=>"Error","message"=>"invalid or missing manufacturer id","data"=>"none");
	echo json_encode($output);
	die();
}
$id=(int)$id;
//get values
$name=$_REQUEST['name'] ?? NULL;
$status=$_REQUEST['status'] ?? NULL;
//check for name
if($name==NULL) {
        $output=array("status"=>"Error","message"=>"missing manufacturer name","data"=>"none");
        echo json_encode($output);
        die();
}
//check for status 
if($status==NULL) {
        $output=array("status"=>"Error","message"=>"missing status","data"=>"none");
        echo json_encode($output);
        die();
}
//validate name
if(!preg_match('/^[A-Z][a-zA-Z]*$/', $name)) {
        $output=array("status"=>"Error","message"=>"invalid characters, only letters and spaces, must start uppercase","data"=>"none");
        echo json_encode($output);
        die();
}
//force active or inactive
if($status !== 'active' && $status !== 'inactive') {
        $output=array("status"=>"Error","message"=>"invalid status","data"=>"none");
        echo json_encode($output);
        die();
}
$dblink=db_connect("equipment");
$escaped=$dblink->real_escape_string($name);
//check dev type exists
$check=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE manufacturer_id=$id");
if($check->num_rows===0) {
        $output=array("status"=>"Error","message"=>"no manufacturer with $id","data"=>"none");
        echo json_encode($output);
        die();
}
//check name not in use
$checkName=$dblink->query("SELECT manufacturer_id FROM manufacturers WHERE name='$escaped' AND manufacturer_id != $id");
if($checkName->num_rows>0) {
        $output=array("status"=>"Error","message"=>"manufacturer '$name' exists already","data"=>"none");
        echo json_encode($output);
        die();
}
//update dev type
$dblink->query("UPDATE manufacturers SET name='$escaped', status='$status' WHERE manufacturer_id=$id");
$output=array("status"=>"Success","message"=>"manufacturer $id updated","data"=>"none");
echo json_encode($output);
?>
